#include "chatframe.h"
#include "ui_chatframe.h"
#include <QGraphicsDropShadowEffect>
#include <QMouseEvent>
#include <QDebug>
#include <QPushButton>
#include <QVBoxLayout>
#include <QGridLayout>
#include <QLabel>
#include <QListWidget>
#include <QStackedWidget>


ChatFrame::ChatFrame(QWidget *parent) :
    QFrame(parent),
    ui(new Ui::ChatFrame)
{
    ui->setupUi(this);
    /*QListWidget *list = new QListWidget(this);   //定义列表项
    list->insertItem(0,tr("windows1"));
    list->insertItem(1,tr("windows2"));
    list->insertItem(2,tr("windows3"));
    list->setAttribute(Qt::WA_TransparentForMouseEvents, false);

    QLabel* label1 = new QLabel(tr("WindowsTest1"));    //生成label对象，并赋值
    QLabel* label2 = new QLabel(tr("WindowsTest2"));
    QLabel* label3 = new QLabel(tr("WindowsTest3"));

    QStackedWidget* stack = new QStackedWidget(this);   //生成堆栈部件对象
    stack->addWidget(label1);   //label对象载入到堆栈部件
    stack->addWidget(label2);
    stack->addWidget(label3);

    QHBoxLayout *mainLayout = new QHBoxLayout(this);    //对整个对话框进行布局
    mainLayout->setMargin(5);   //控件距离边界的距离
    mainLayout->setSpacing(0);
    mainLayout->addWidget(list);
    mainLayout->addWidget(stack,0,Qt::AlignHCenter);    //默认左对齐
    mainLayout->setStretchFactor(list,1);
    mainLayout->setStretchFactor(stack,3);
    connect(list,SIGNAL(currentRowChanged(int)),stack,SLOT(setCurrentIndex(int)));*/
}

ChatFrame::~ChatFrame()
{
    delete ui;
}
