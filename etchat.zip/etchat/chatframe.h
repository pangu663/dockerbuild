#ifndef CHATFRAME_H
#define CHATFRAME_H

#include <QFrame>
namespace Ui {
class ChatFrame;
}
class ChatFrame : public QFrame
{
    Q_OBJECT

public:
    explicit ChatFrame(QWidget *parent = nullptr);
    ~ChatFrame();
private:
    Ui::ChatFrame *ui;
};

#endif // CHATFRAME_H
