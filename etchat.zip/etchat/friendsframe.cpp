#include "friendsframe.h"
#include "ui_friendsframe.h"

FriendsFrame::FriendsFrame(QWidget *parent) :
    QFrame(parent),
    ui(new Ui::FriendsFrame)
{
    ui->setupUi(this);
}

FriendsFrame::~FriendsFrame()
{
    delete ui;
}
