#ifndef FRIENDSFRAME_H
#define FRIENDSFRAME_H

#include <QFrame>

namespace Ui {
class FriendsFrame;
}

class FriendsFrame : public QFrame
{
    Q_OBJECT

public:
    explicit FriendsFrame(QWidget *parent = nullptr);
    ~FriendsFrame();

private:
    Ui::FriendsFrame *ui;
};

#endif // FRIENDSFRAME_H
