#include "friframe.h"
#include "ui_friframe.h"

FriFrame::FriFrame(QWidget *parent) :
    QFrame(parent),
    ui(new Ui::FriFrame)
{
    ui->setupUi(this);
}

FriFrame::~FriFrame()
{
    delete ui;
}
