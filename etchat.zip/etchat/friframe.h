#ifndef FRIFRAME_H
#define FRIFRAME_H

#include <QFrame>

namespace Ui {
class FriFrame;
}

class FriFrame : public QFrame
{
    Q_OBJECT

public:
    explicit FriFrame(QWidget *parent = nullptr);
    ~FriFrame();

private:
    Ui::FriFrame *ui;
};

#endif // FRIFRAME_H
