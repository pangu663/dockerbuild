#include "groupframe.h"
#include "ui_groupframe.h"

GroupFrame::GroupFrame(QWidget *parent) :
    QFrame(parent),
    ui(new Ui::GroupFrame)
{
    ui->setupUi(this);
}

GroupFrame::~GroupFrame()
{
    delete ui;
}
