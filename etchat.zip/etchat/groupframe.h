#ifndef GROUPFRAME_H
#define GROUPFRAME_H

#include <QFrame>

namespace Ui {
class GroupFrame;
}

class GroupFrame : public QFrame
{
    Q_OBJECT

public:
    explicit GroupFrame(QWidget *parent = nullptr);
    ~GroupFrame();

private:
    Ui::GroupFrame *ui;
};

#endif // GROUPFRAME_H
