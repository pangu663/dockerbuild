#include "joinframe.h"
#include "ui_joinframe.h"

JoinFrame::JoinFrame(QWidget *parent) :
    QFrame(parent),
    ui(new Ui::JoinFrame)
{
    ui->setupUi(this);
}

JoinFrame::~JoinFrame()
{
    delete ui;
}
