#ifndef JOINFRAME_H
#define JOINFRAME_H

#include <QFrame>

namespace Ui {
class JoinFrame;
}

class JoinFrame : public QFrame
{
    Q_OBJECT

public:
    explicit JoinFrame(QWidget *parent = nullptr);
    ~JoinFrame();

private:
    Ui::JoinFrame *ui;
};

#endif // JOINFRAME_H
