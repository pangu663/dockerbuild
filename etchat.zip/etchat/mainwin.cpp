#include "mainwin.h"
#include "ui_mainwin.h"
#include <QMouseEvent>
#include <QGraphicsDropShadowEffect>
#include <QDebug>
#include <QPushButton>
#include <QVBoxLayout>
#include <QBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QLabel>
#include <QMessageBox>
#include <QStackedWidget>
#include <QListWidget>


MainWin::MainWin(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MainWin)
{
    ui->setupUi(this);
    isLeftPressDown = false;
    this->dir = NONE;
    this->setMinimumWidth(810);
    this->setMinimumHeight(500);
    this->setWindowFlags(Qt::FramelessWindowHint|Qt::WindowSystemMenuHint );
    this->setAttribute(Qt::WA_TranslucentBackground, true);//设置为透明背景
    this->setMouseTracking(true);
    //ui->frame->setAttribute(Qt::WA_TransparentForMouseEvents, true);
    //ui->frame_2->setAttribute(Qt::WA_TransparentForMouseEvents, true);
    //ui->chat->setAttribute(Qt::WA_TransparentForMouseEvents, true);
    //ui->chat->setAttribute(Qt::WA_TransparentForMouseEvents, false);
    QGraphicsDropShadowEffect *effect = new QGraphicsDropShadowEffect(this);
    effect->setOffset(0, 0);          //设置向哪个方向产生阴影效果(dx,dy)，特别地，(0,0)代表向四周发散
    effect->setColor(QColor(0,0,0));  //设置阴影颜色，也可以setColor(QColor(220,220,220))
    effect->setBlurRadius(10);        //设定阴影的模糊半径，数值越大越模糊
    ui->frame->setGraphicsEffect(effect);

    imginfo.imgurl = ":/static/images/static/images/left1.png";
    imginfo.width   = 34;
    imginfo.height  = 34;
    this->loadimg(ui->chat,imginfo);
    imginfo.imgurl = ":/static/images/static/images/left4.png";
    imginfo.width   = 34;
    imginfo.height  = 34;
    this->loadimg(ui->friends,imginfo);
    imginfo.imgurl = ":/static/images/static/images/left6.png";
    imginfo.width   = 34;
    imginfo.height  = 34;
    this->loadimg(ui->group,imginfo);
    imginfo.imgurl = ":/static/images/static/images/left8.png";
    imginfo.width   = 34;
    imginfo.height  = 34;
    this->loadimg(ui->join,imginfo);

    imginfo.imgurl = ":/static/images/static/images/setting.png";
    imginfo.width   = 30;
    imginfo.height  = 30;
    this->loadimg(ui->setting,imginfo);

    QFrame *chat = new ChatFrame(ui->frame);
    QFrame *friends = new FriendsFrame(ui->frame);
    QFrame *group = new GroupFrame(ui->frame);
    QFrame *join = new JoinFrame(ui->frame);

    /*chat->setObjectName(QString::fromUtf8("chat"));
    QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Preferred);
    sizePolicy1.setHeightForWidth(chat->sizePolicy().hasHeightForWidth());
    chat->setSizePolicy(sizePolicy1);*/
    //chat->setMinimumSize(QSize(305, 0));
    //chat->setMaximumSize(QSize(16777215, 16777215));
    //chat->setStyleSheet(QString::fromUtf8(""));
    //chat->setFrameShape(QFrame::StyledPanel);
    //chat->setFrameShadow(QFrame::Raised);

    stack = new QStackedWidget(this);   //生成堆栈部件对象
    stack->addWidget(chat);   //label对象载入到堆栈部件
    stack->addWidget(friends);
    stack->addWidget(group);
    stack->addWidget(join);
    ui->gridLayout_6->addWidget(stack, 0, 1, 1, 1);

    connect(ui->chat,&myLabel::clicked,this, &MainWin::chatClicked);
    connect(ui->friends,&myLabel::clicked,this, &MainWin::friendsClicked);
    connect(ui->group,&myLabel::clicked,this, &MainWin::groupClicked);
    connect(ui->join,&myLabel::clicked,this, &MainWin::joinClicked);
    connect(ui->avatar,&myLabel::clicked,this, &MainWin::avatarClicked);
    connect(ui->setting,&myLabel::clicked,this, &MainWin::settingClicked);
}

MainWin::~MainWin()
{
    delete ui;
}
// 聊天槽函数：
void MainWin::chatClicked()
{
    qDebug() << "聊天槽函数：";
    isLeftPressDown = false;
    imginfo.imgurl = ":/static/images/static/images/left1.png";
    imginfo.width   = 34;
    imginfo.height  = 34;
    this->loadimg(ui->chat,imginfo);
    imginfo.imgurl = ":/static/images/static/images/left4.png";
    imginfo.width   = 34;
    imginfo.height  = 34;
    this->loadimg(ui->friends,imginfo);
    imginfo.imgurl = ":/static/images/static/images/left6.png";
    imginfo.width   = 34;
    imginfo.height  = 34;
    this->loadimg(ui->group,imginfo);
    imginfo.imgurl = ":/static/images/static/images/left8.png";
    imginfo.width   = 34;
    imginfo.height  = 34;
    this->loadimg(ui->join,imginfo);
    stack->setCurrentIndex(0);
    if(dir != NONE) {
        this->releaseMouse();
        this->setCursor(QCursor(Qt::ArrowCursor));
    }
}
// 好友槽函数：
void MainWin::friendsClicked()
{
    qDebug() << "好友槽函数：";
    isLeftPressDown = false;
    imginfo.imgurl = ":/static/images/static/images/left2.png";
    imginfo.width   = 34;
    imginfo.height  = 34;
    this->loadimg(ui->chat,imginfo);
    imginfo.imgurl = ":/static/images/static/images/left3.png";
    imginfo.width   = 34;
    imginfo.height  = 34;
    this->loadimg(ui->friends,imginfo);
    imginfo.imgurl = ":/static/images/static/images/left6.png";
    imginfo.width   = 34;
    imginfo.height  = 34;
    this->loadimg(ui->group,imginfo);
    imginfo.imgurl = ":/static/images/static/images/left8.png";
    imginfo.width   = 34;
    imginfo.height  = 34;
    this->loadimg(ui->join,imginfo);
    stack->setCurrentIndex(1);
    if(dir != NONE) {
        this->releaseMouse();
        this->setCursor(QCursor(Qt::ArrowCursor));
    }
}
// 群聊槽函数：
void MainWin::groupClicked()
{
    qDebug() << "群聊槽函数：";
    isLeftPressDown = false;
    imginfo.imgurl = ":/static/images/static/images/left2.png";
    imginfo.width   = 34;
    imginfo.height  = 34;
    this->loadimg(ui->chat,imginfo);
    imginfo.imgurl = ":/static/images/static/images/left4.png";
    imginfo.width   = 34;
    imginfo.height  = 34;
    this->loadimg(ui->friends,imginfo);
    imginfo.imgurl = ":/static/images/static/images/left5.png";
    imginfo.width   = 34;
    imginfo.height  = 34;
    this->loadimg(ui->group,imginfo);
    imginfo.imgurl = ":/static/images/static/images/left8.png";
    imginfo.width   = 34;
    imginfo.height  = 34;
    this->loadimg(ui->join,imginfo);
    stack->setCurrentIndex(2);
    if(dir != NONE) {
        this->releaseMouse();
        this->setCursor(QCursor(Qt::ArrowCursor));
    }
}
// 消息槽函数：
void MainWin::joinClicked()
{
    qDebug() << "消息槽函数：";
    isLeftPressDown = false;
    imginfo.imgurl = ":/static/images/static/images/left2.png";
    imginfo.width   = 34;
    imginfo.height  = 34;
    this->loadimg(ui->chat,imginfo);
    imginfo.imgurl = ":/static/images/static/images/left4.png";
    imginfo.width   = 34;
    imginfo.height  = 34;
    this->loadimg(ui->friends,imginfo);
    imginfo.imgurl = ":/static/images/static/images/left6.png";
    imginfo.width   = 34;
    imginfo.height  = 34;
    this->loadimg(ui->group,imginfo);
    imginfo.imgurl = ":/static/images/static/images/left7.png";
    imginfo.width   = 34;
    imginfo.height  = 34;
    this->loadimg(ui->join,imginfo);
    stack->setCurrentIndex(3);
    if(dir != NONE) {
        this->releaseMouse();
        this->setCursor(QCursor(Qt::ArrowCursor));
    }
}
// 头像槽函数：
void MainWin::avatarClicked(){
    qDebug() << "头像槽函数：";
    isLeftPressDown = false;
    if(dir != NONE) {
        this->releaseMouse();
        this->setCursor(QCursor(Qt::ArrowCursor));
    }
}
// 设置槽函数：
void MainWin::settingClicked(){
    qDebug() << "设置槽函数：";
    isLeftPressDown = false;
    if(dir != NONE) {
        this->releaseMouse();
        this->setCursor(QCursor(Qt::ArrowCursor));
    }
}
void MainWin::focusOutEvent(QFocusEvent * event){
     qDebug() << "9090909090909090909";
}
void MainWin::focusInEvent(QFocusEvent * event){
     qDebug() << "8080808080800808";
}
void MainWin::loadimg(QLabel *event,Imginfo imginfo)
{
    QImage* tiplogoimg=new QImage;//分别保存原图和缩放之后的图片
    if(! ( tiplogoimg->load(imginfo.imgurl) ) ) {//加载图像
        QMessageBox::information(this,tr("打开图像失败"),tr("打开图像失败!"));
        delete tiplogoimg;
        return;
    }
    event->setAttribute(Qt::WA_TranslucentBackground , true);//透明度设置
    event->setAutoFillBackground(false);//设置不允许自动填充背景
    event->setPixmap(QPixmap::fromImage(*tiplogoimg)
            .scaled(imginfo.width, imginfo.height, Qt::KeepAspectRatio, Qt::SmoothTransformation));
    qDebug() << "载入图片结束";
}
void MainWin::mouseReleaseEvent(QMouseEvent *event)
{
    if(event->button() == Qt::LeftButton) {
        isLeftPressDown = false;
        QPoint gloPoint = event->globalPos();
        this->region(gloPoint);
        if(dir != NONE) {
            this->releaseMouse();
            this->setCursor(QCursor(Qt::ArrowCursor));
        }
    }
}

void MainWin::mousePressEvent(QMouseEvent *event)
{
    switch(event->button()) {
    case Qt::LeftButton:
        isLeftPressDown = true;
        qDebug() << "000000000000";
        if(dir != NONE) {
            QPoint gloPoint = event->globalPos();
            this->region(gloPoint);
            this->mouseGrabber();
        } else {
            dragPosition = event->globalPos() - this->frameGeometry().topLeft();
        }
        break;
    case Qt::RightButton:
        this->close();
        break;
    default:
        QWidget::mousePressEvent(event);
    }

}

void MainWin::mouseMoveEvent(QMouseEvent *event)
{
    QPoint gloPoint = event->globalPos();
    QRect rect = this->rect();
    QPoint tl = mapToGlobal(rect.topLeft());
    QPoint rb = mapToGlobal(rect.bottomRight());
    if(!isLeftPressDown&&this->isActiveWindow()) {
        qDebug() << "222222";
        this->region(gloPoint);
    } else if(this->isActiveWindow()) {
        qDebug() << dir;

        qDebug() << gloPoint;
        if(dir != NONE) {
            qDebug() << "55555555555555";
            //this->region(gloPoint);
            QRect rMove(tl, rb);
            switch(dir) {
            case LEFT:
                if(rb.x() - gloPoint.x() <= this->minimumWidth())
                    rMove.setX(tl.x());
                else
                    rMove.setX(gloPoint.x());
                break;
            case RIGHT:
                rMove.setWidth(gloPoint.x() - tl.x());
                break;
            case UP:
                if(rb.y() - gloPoint.y() <= this->minimumHeight())
                    rMove.setY(tl.y());
                else
                    rMove.setY(gloPoint.y());
                break;
            case DOWN:
                rMove.setHeight(gloPoint.y() - tl.y());
                break;
            case LEFTTOP:
                if(rb.x() - gloPoint.x() <= this->minimumWidth())
                    rMove.setX(tl.x());
                else
                    rMove.setX(gloPoint.x());
                if(rb.y() - gloPoint.y() <= this->minimumHeight())
                    rMove.setY(tl.y());
                else
                    rMove.setY(gloPoint.y());
                break;
            case RIGHTTOP:
                rMove.setWidth(gloPoint.x() - tl.x());
                rMove.setY(gloPoint.y());
                break;
            case LEFTBOTTOM:
                rMove.setX(gloPoint.x());
                rMove.setHeight(gloPoint.y() - tl.y());
                break;
            case RIGHTBOTTOM:
                rMove.setWidth(gloPoint.x() - tl.x());
                rMove.setHeight(gloPoint.y() - tl.y());
                break;
            default:
                break;
            }
            this->setGeometry(rMove);
        } else {
            qDebug() << "666666666";
            move(event->globalPos() - dragPosition);
            event->accept();
        }
    }else{
        dir = NONE;// 默认
        this->setCursor(QCursor(Qt::ArrowCursor));
    }
    QWidget::mouseMoveEvent(event);
}

void MainWin::region(const QPoint &cursorGlobalPoint){
    QRect rect = this->rect();
    QPoint tl = mapToGlobal(rect.topLeft());
    QPoint rb = mapToGlobal(rect.bottomRight());
    int x = cursorGlobalPoint.x();
    int y = cursorGlobalPoint.y();
    if(tl.x() + PADDING >= x && tl.x() <= x && tl.y() + PADDING >= y && tl.y() <= y) {
        dir = LEFTTOP;// 左上角
        qDebug() << "LEFTTOP";
        this->setCursor(QCursor(Qt::SizeFDiagCursor));
    } else if(x >= rb.x() - PADDING && x <= rb.x() && y >= rb.y() - PADDING && y <= rb.y()) {
        dir = RIGHTBOTTOM;// 右下角
        qDebug() << "RIGHTBOTTOM";
        this->setCursor(QCursor(Qt::SizeFDiagCursor));
    } else if(x <= tl.x() + PADDING && x >= tl.x() && y >= rb.y() - PADDING && y <= rb.y()) {
        dir = LEFTBOTTOM;//左下角
        qDebug() << "LEFTBOTTOM";
        this->setCursor(QCursor(Qt::SizeBDiagCursor));
    } else if(x <= rb.x() && x >= rb.x() - PADDING && y >= tl.y() && y <= tl.y() + PADDING) {
        dir = RIGHTTOP;// 右上角
        qDebug() << "RIGHTTOP";
        this->setCursor(QCursor(Qt::SizeBDiagCursor));
    } else if(x <= tl.x() + PADDING && x >= tl.x()) {
        dir = LEFT;// 左边
        qDebug() << "LEFT";
        this->setCursor(QCursor(Qt::SizeHorCursor));
    } else if( x <= rb.x() && x >= rb.x() - PADDING) {
        dir = RIGHT;// 右边
        qDebug() << "RIGHT";
        this->setCursor(QCursor(Qt::SizeHorCursor));
    }else if(y >= tl.y() && y <= tl.y() + PADDING){
        dir = UP;// 上边
        qDebug() << "UP";
        this->setCursor(QCursor(Qt::SizeVerCursor));
    } else if(y <= rb.y() && y >= rb.y() - PADDING) {
        dir = DOWN;// 下边
        qDebug() << "DOWN";
        this->setCursor(QCursor(Qt::SizeVerCursor));
    }else {
        dir = NONE;// 默认
        qDebug() << "NONE";
        this->setCursor(QCursor(Qt::ArrowCursor));
    }
}
bool MainWin::event(QEvent * event) {
    qDebug() << event->type();
    if (event->type() == QEvent::ActivationChange){
        if(QApplication::activeWindow() != this){
              dir = NONE;// 默认
              this->setCursor(QCursor(Qt::ArrowCursor));
        }
    }else if(event->type() == QEvent::Leave) {
        dir = NONE;// 默认
        this->setCursor(QCursor(Qt::ArrowCursor));
    }
    return QWidget::event(event);
}
