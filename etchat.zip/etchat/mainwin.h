#ifndef MAINWIN_H
#define MAINWIN_H

#include <QWidget>
#include <QLabel>
#include <QMouseEvent>
#include <QPoint>
#include <QCursor>
#include <QRect>
#include <QStackedWidget>
#include "chatframe.h"
#include "friendsframe.h"
#include "groupframe.h"
#include "joinframe.h"
#define PADDING 6
namespace Ui {
class MainWin;
}
enum Direction{
    UP = 0,DOWN=1,LEFT,RIGHT,LEFTTOP,LEFTBOTTOM,RIGHTBOTTOM,RIGHTTOP,NONE
};
class MainWin : public QWidget
{
    Q_OBJECT

public:
    explicit MainWin(QWidget *parent = nullptr);
    ~MainWin();
private slots:
    void chatClicked(); // 添加槽声明
    void friendsClicked(); // 添加槽声明
    void groupClicked(); // 添加槽声明
    void joinClicked(); // 添加槽声明
    void avatarClicked(); // 添加头像槽声明
    void settingClicked(); // 添加设置槽声明
private:
    void region(const QPoint &cursorPoint);
protected:
    struct Imginfo{
       QString  imgurl;
       int   width;
       int   height;
    };
    Imginfo imginfo;
    void mouseReleaseEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
    void mousePressEvent(QMouseEvent *event);
    void focusOutEvent(QFocusEvent * event);
    void focusInEvent(QFocusEvent * event);
    bool event(QEvent * event);
    void loadimg(QLabel *event,Imginfo imginfo);
private:
    bool isLeftPressDown;
    QPoint dragPosition;
    Direction dir;
    QStackedWidget* stack;
private:
    Ui::MainWin *ui;
};

#endif // MAINWIN_H
