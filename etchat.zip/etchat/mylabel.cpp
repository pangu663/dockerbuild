#include "mylabel.h"

myLabel::myLabel(QWidget *parent):QLabel(parent)
{

}

// 重写鼠标释放时间 mouseReleaseEvent()
void myLabel::mouseReleaseEvent(QMouseEvent *ev)
{
    Q_UNUSED(ev)
    if(ev->button() == Qt::LeftButton)
    {
        emit clicked();	// 发射信号
    }
}
