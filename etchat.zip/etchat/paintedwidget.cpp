#include "paintedwidget.h"
#include <QPainter>
#include <QDebug>

PaintedWidget::PaintedWidget(QWidget *parent)
    :QWidget(parent)
{
    //resize(800, 600);
    //setWindowTitle(tr("Paint Demo"));
    QString s = "hello";
    qDebug() << s;
    QPainter painter(this);
    QImage *pimage=new QImage(":/static/images/static/images/loginlogo.png");
    painter.drawImage(pimage->rect(),*pimage);
    s = "22222222222222";
    qDebug() << s;
}

void PaintedWidget::paintEvent(QPaintEvent *)
{
    QString s = "helddddlo";
    qDebug() << s;
}
