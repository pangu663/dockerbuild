#include "widget.h"
#include "paintedwidget.h"
#include "ui_widget.h"
#include <QMovie>
#include <QMessageBox>
#include <QToolButton>
#include <QMouseEvent>
#include <QHBoxLayout>
#include <QGraphicsDropShadowEffect>

#define SHADOW_WIDTH 10			// 阴影边框宽度;

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    //PaintedWidget p;
    //p.show();| Qt::Tool
    this->setWindowFlags(Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint);
    this->setAttribute(Qt::WA_TranslucentBackground, true);      //设置为透明背景
    ui->setupUi(this);

    QGraphicsDropShadowEffect *effect = new QGraphicsDropShadowEffect(this);
    effect->setOffset(0, 0);          //设置向哪个方向产生阴影效果(dx,dy)，特别地，(0,0)代表向四周发散
    effect->setColor(QColor(0,0,0));       //设置阴影颜色，也可以setColor(QColor(220,220,220))
    effect->setBlurRadius(10);        //设定阴影的模糊半径，数值越大越模糊
    ui->frame->setGraphicsEffect(effect);

    imginfo.imgurl = ":/static/images/static/images/loginlogo.png";
    imginfo.width   = 121;
    imginfo.height  = 31;
    this->loadimg(ui->tiplogo,imginfo);

    imginfo.imgurl = ":/static/images/static/images/logo.png";
    imginfo.width   = 110;
    imginfo.height  = 110;
    this->loadimg(ui->logo,imginfo);

    imginfo.imgurl = ":/static/images/static/images/close.png";
    imginfo.width   = 21;
    imginfo.height  = 21;
    this->loadimg(ui->close,imginfo);

    imginfo.imgurl = ":/static/images/static/images/user.png";
    imginfo.width   = 21;
    imginfo.height  = 21;
    this->loadimg(ui->user,imginfo);

    imginfo.imgurl = ":/static/images/static/images/password.png";
    imginfo.width   = 21;
    imginfo.height  = 21;
    this->loadimg(ui->password,imginfo);

    imginfo.imgurl = ":/static/images/static/images/down.png";
    imginfo.width   = 21;
    imginfo.height  = 21;
    this->loadimg(ui->down,imginfo);

    /*//获取界面的宽度
    int width = this->width();
    //构建最小化、最大化、关闭按钮
    QToolButton *minButton = new QToolButton(this);
    QToolButton *closeButton= new QToolButton(this);
    //设置最小化、关闭按钮在界面的位置
    minButton->setGeometry(width-46,5,20,20);
    closeButton->setGeometry(width-25,5,20,20);
    //设置鼠标移至按钮上的提示信息
    minButton->setToolTip(tr("最小化"));
    closeButton->setToolTip(tr("关闭"));
    //设置最小化、关闭按钮的样式
    minButton->setStyleSheet("background-color:transparent;");
    closeButton->setStyleSheet("background-color:transparent;");
    //关联最小化、关闭按钮的槽函数
    connect(minButton, SIGNAL(clicked()), this, SLOT(slot_minWindow()));
    connect(closeButton, SIGNAL(clicked()), this, SLOT(close()));*/
    QMovie *movie=new QMovie(":/static/images/static/images/login-back.gif");
    ui->iback->setMovie(movie);
    movie->start();
}

Widget::~Widget()
{
    delete ui;
}

void Widget::mousePressEvent(QMouseEvent *event)
{
    m_draging = true;
    if(event->buttons() & Qt::LeftButton)//只响应鼠标左键
    {
        m_startPostion = event->globalPos();
        m_framPostion = frameGeometry().topLeft();
    }
    QWidget::mousePressEvent(event);//调用父类函数保持原按键行为
}

void Widget::mouseMoveEvent(QMouseEvent *event)
{
    if(event->buttons() & Qt::LeftButton)
    {
        //offset 偏移位置
        QPoint offset = event->globalPos() - m_startPostion;
        move(m_framPostion + offset);
    }
    QWidget::mouseMoveEvent(event);//调用父类函数保持原按键行为
}

void Widget::mouseReleaseEvent(QMouseEvent *event)
{
    m_draging = false;
    QWidget::mouseReleaseEvent(event);
}

void Widget::loadimg(QLabel *event,Imginfo imginfo)
{
    QImage* tiplogoimg=new QImage;//分别保存原图和缩放之后的图片
    if(! ( tiplogoimg->load(imginfo.imgurl) ) ) {//加载图像
        QMessageBox::information(this,tr("打开图像失败"),tr("打开图像失败!"));
        delete tiplogoimg;
        return;
    }
    event->setAttribute(Qt::WA_TranslucentBackground , true);//透明度设置
    event->setAutoFillBackground(false);//设置不允许自动填充背景
    event->setPixmap(QPixmap::fromImage(*tiplogoimg)
            .scaled(imginfo.width, imginfo.height, Qt::KeepAspectRatio, Qt::SmoothTransformation));
    qDebug() << "载入图片结束";
}

void Widget::paintEvent(QPaintEvent *event)
{
    /*QPainter painter(this);
    QColor color(0, 0, 0, 0);
    for(int i=0; i<6; i++){
          QPainterPath path;
          path.setFillRule(Qt::WindingFill);
          path.addRect(6-i, 6-i, this->width()-(6-i)*2, this->height()-(6-i)*2);
          color.setAlpha(50 - i*10);
          painter.setPen(color);
          painter.drawPath(path);
    }*/
    /*
    painter.fillRect(this->rect()
     .adjusted(SHADOW_WIDTH, SHADOW_WIDTH, -SHADOW_WIDTH, -SHADOW_WIDTH)
     , QColor(238, 223, 204));
    / 2、设置阴影边框;
    QGraphicsDropShadowEffect* shadowEffect = new QGraphicsDropShadowEffect(this);
    // 阴影偏移
    shadowEffect->setOffset(5, 5);
    // 阴影颜色;
    shadowEffect->setColor(Qt::black);
    // 阴影半径;
    shadowEffect->setBlurRadius(10);
    // 给窗口设置上当前的阴影效果;
    this->setGraphicsEffect(shadowEffect);*/
}

void Widget::on_pushButton_clicked()
{
    mw.setWindowIcon(QIcon(":/static/icons/static/icons/icon.ico"));
    mw.show();
    qDebug() << mw.windowState();
    this->hide();
}
