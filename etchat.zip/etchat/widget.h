#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QLabel>
#include <QtGui>
#include "mainwin.h"


QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private slots:
    void on_pushButton_clicked();

private:
    Ui::Widget *ui;
    struct Imginfo{
       QString  imgurl;
       int   width;
       int   height;
    };
    Imginfo imginfo;
    MainWin mw;
    void mousePressEvent(QMouseEvent *event);//按下
    void mouseMoveEvent(QMouseEvent *event);//移动
    void mouseReleaseEvent(QMouseEvent *event);//抬起
    void paintEvent(QPaintEvent *event);//重构paintEvent
    void loadimg(QLabel *event,Imginfo imginfo);
private:
    bool m_draging;//是否拖动
    QPoint m_startPostion;//拖动前鼠标位置
    QPoint m_framPostion;//窗体的原始位置
};
#endif // WIDGET_H
